- Picture of euclid (`./examples/euclid.jpg`) thanks to [Wikipedia][1]
- Prime number picture (`./examples/primes.jpg`) thanks to [Geralt][2]

[1]: https://en.wikipedia.org/wiki/Euclid#/media/File:Euklid-von-Alexandria_1.jpg
[2]: https://pixabay.com/de/users/geralt-9301/
